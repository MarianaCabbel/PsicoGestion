export const NAME_MAX = 50
export const PASSWORD_MIN = 8
export const PASSWORD_MAX = 25

export type PasswordChecks = {
  length: boolean
  uppercase: boolean
  number: boolean
  special: boolean
}

export function checkPassword(value: string): PasswordChecks {
  return {
    length: value.length >= PASSWORD_MIN && value.length <= PASSWORD_MAX,
    uppercase: /[A-ZÁÉÍÓÚÑ]/.test(value),
    number: /[0-9]/.test(value),
    special: /[^A-Za-z0-9]/.test(value),
  }
}

export function isPasswordValid(value: string): boolean {
  const c = checkPassword(value)
  return c.length && c.uppercase && c.number && c.special
}

/** Correo institucional UADY: cualquier subdominio que termine en uady.mx */
export function isInstitutionalEmail(value: string): boolean {
  return /^[^\s@]+@([a-z0-9-]+\.)*uady\.mx$/i.test(value.trim())
}

/** Teléfono de 10 dígitos (formato nacional). */
export function isValidPhone(value: string): boolean {
  return /^\d{10}$/.test(value.replace(/\D/g, ''))
}

export function isValidName(value: string): boolean {
  const v = value.trim()
  return v.length >= 3 && v.length <= NAME_MAX
}
