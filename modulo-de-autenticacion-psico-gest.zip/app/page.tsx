'use client'

import { useState } from 'react'
import { BrainCircuit } from 'lucide-react'
import { BrandPanel } from '@/components/auth/brand-panel'
import { RegisterForm } from '@/components/auth/register-form'
import { VerifyCodeForm } from '@/components/auth/verify-code-form'
import { SuccessCard } from '@/components/auth/success-card'

type Step = 'register' | 'verify' | 'success'

export default function Page() {
  const [step, setStep] = useState<Step>('register')
  const [email, setEmail] = useState('')

  return (
    <main className="grid min-h-screen lg:grid-cols-[1fr_1.1fr]">
      <BrandPanel />

      <section className="flex items-center justify-center px-4 py-10 sm:px-8">
        <div className="w-full max-w-md">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <BrainCircuit className="size-5" aria-hidden="true" />
            </span>
            <div>
              <p className="font-semibold leading-tight text-foreground">PsicoGestión</p>
              <p className="text-xs text-muted-foreground">Clínica Universitaria UADY</p>
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8">
            {step === 'register' && (
              <>
                <header className="mb-6">
                  <h1 className="text-2xl font-semibold text-foreground">Crear cuenta administrativa</h1>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Registra tus datos para gestionar las citas de la clínica.
                  </p>
                </header>
                <RegisterForm
                  onRegistered={(value) => {
                    setEmail(value)
                    setStep('verify')
                  }}
                />
              </>
            )}

            {step === 'verify' && (
              <VerifyCodeForm
                email={email}
                onVerified={() => setStep('success')}
                onBack={() => setStep('register')}
              />
            )}

            {step === 'success' && <SuccessCard onRestart={() => setStep('register')} />}
          </div>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            © {new Date().getFullYear()} Clínica Universitaria UADY · PsicoGestión
          </p>
        </div>
      </section>
    </main>
  )
}
