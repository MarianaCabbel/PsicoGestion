'use client'

import { CircleCheckBig } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function SuccessCard({ onRestart }: { onRestart: () => void }) {
  return (
    <div className="flex flex-col items-center gap-5 text-center">
      <span className="flex size-14 items-center justify-center rounded-full bg-accent text-primary">
        <CircleCheckBig className="size-7" aria-hidden="true" />
      </span>
      <div>
        <h2 className="text-xl font-semibold text-foreground">Cuenta verificada</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Tu cuenta administrativa quedó activa. Ya puedes iniciar sesión en PsicoGestión.
        </p>
      </div>
      <Button onClick={onRestart} className="h-11 w-full text-sm font-semibold">
        Ir al inicio de sesión
      </Button>
    </div>
  )
}
