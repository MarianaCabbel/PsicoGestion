'use client'

import { useMemo, useState } from 'react'
import {
  Check,
  Eye,
  EyeOff,
  Lock,
  LoaderCircle,
  Mail,
  Phone,
  User,
  X,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Field } from '@/components/auth/field'
import {
  NAME_MAX,
  checkPassword,
  isInstitutionalEmail,
  isPasswordValid,
  isValidName,
  isValidPhone,
} from '@/lib/auth-validation'
import { cn } from '@/lib/utils'

type Values = {
  name: string
  email: string
  phone: string
  password: string
  confirm: string
}

type Errors = Partial<Record<keyof Values, string>>

const empty: Values = { name: '', email: '', phone: '', password: '', confirm: '' }

function validate(values: Values): Errors {
  const errors: Errors = {}

  if (!values.name.trim()) errors.name = 'Ingresa tu nombre completo.'
  else if (!isValidName(values.name))
    errors.name = `El nombre debe tener entre 3 y ${NAME_MAX} caracteres.`

  if (!values.email.trim()) errors.email = 'Ingresa tu correo institucional.'
  else if (!isInstitutionalEmail(values.email))
    errors.email = 'Usa un correo institucional válido (@…uady.mx).'

  if (!values.phone.trim()) errors.phone = 'Ingresa tu teléfono.'
  else if (!isValidPhone(values.phone))
    errors.phone = 'El teléfono debe tener 10 dígitos.'

  if (!values.password) errors.password = 'Crea una contraseña.'
  else if (!isPasswordValid(values.password))
    errors.password = 'La contraseña no cumple los requisitos.'

  if (!values.confirm) errors.confirm = 'Confirma tu contraseña.'
  else if (values.confirm !== values.password)
    errors.confirm = 'Las contraseñas no coinciden.'

  return errors
}

export function RegisterForm({
  onRegistered,
}: {
  onRegistered: (email: string) => void
}) {
  const [values, setValues] = useState<Values>(empty)
  const [touched, setTouched] = useState<Partial<Record<keyof Values, boolean>>>({})
  const [submitted, setSubmitted] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [pending, setPending] = useState(false)

  const errors = useMemo(() => validate(values), [values])
  const pwChecks = useMemo(() => checkPassword(values.password), [values.password])

  function shouldShow(field: keyof Values) {
    return (submitted || touched[field]) && errors[field]
  }

  function update(field: keyof Values, value: string) {
    setValues((prev) => ({ ...prev, [field]: value }))
  }

  function blur(field: keyof Values) {
    setTouched((prev) => ({ ...prev, [field]: true }))
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setSubmitted(true)
    if (Object.keys(errors).length > 0) {
      const first = document.querySelector<HTMLElement>('[aria-invalid="true"]')
      first?.focus()
      return
    }
    setPending(true)
    // Simula el envío del código de verificación al correo institucional.
    await new Promise((resolve) => setTimeout(resolve, 700))
    setPending(false)
    onRegistered(values.email.trim())
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
      <Field
        label="Nombre completo"
        icon={<User className="size-4" aria-hidden="true" />}
        placeholder="Ej. María López Canul"
        autoComplete="name"
        maxLength={NAME_MAX}
        value={values.name}
        onChange={(e) => update('name', e.target.value)}
        onBlur={() => blur('name')}
        error={shouldShow('name') ? errors.name : undefined}
        hint={`${values.name.length}/${NAME_MAX} caracteres`}
      />

      <Field
        label="Correo institucional"
        type="email"
        inputMode="email"
        icon={<Mail className="size-4" aria-hidden="true" />}
        placeholder="usuario@correo.uady.mx"
        autoComplete="email"
        value={values.email}
        onChange={(e) => update('email', e.target.value)}
        onBlur={() => blur('email')}
        error={shouldShow('email') ? errors.email : undefined}
      />

      <Field
        label="Teléfono"
        type="tel"
        inputMode="numeric"
        icon={<Phone className="size-4" aria-hidden="true" />}
        placeholder="9991234567"
        autoComplete="tel"
        maxLength={10}
        value={values.phone}
        onChange={(e) => update('phone', e.target.value.replace(/\D/g, ''))}
        onBlur={() => blur('phone')}
        error={shouldShow('phone') ? errors.phone : undefined}
        hint="10 dígitos. Debe ser único por cada cuenta."
      />

      <Field
        label="Contraseña"
        type={showPassword ? 'text' : 'password'}
        icon={<Lock className="size-4" aria-hidden="true" />}
        placeholder="Crea una contraseña segura"
        autoComplete="new-password"
        maxLength={25}
        value={values.password}
        onChange={(e) => update('password', e.target.value)}
        onBlur={() => blur('password')}
        error={shouldShow('password') ? errors.password : undefined}
        trailing={
          <button
            type="button"
            onClick={() => setShowPassword((s) => !s)}
            className="rounded p-1 text-muted-foreground outline-none hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
          >
            {showPassword ? (
              <EyeOff className="size-4" aria-hidden="true" />
            ) : (
              <Eye className="size-4" aria-hidden="true" />
            )}
          </button>
        }
      />

      <PasswordChecklist checks={pwChecks} active={values.password.length > 0} />

      <Field
        label="Confirmar contraseña"
        type={showPassword ? 'text' : 'password'}
        icon={<Lock className="size-4" aria-hidden="true" />}
        placeholder="Repite tu contraseña"
        autoComplete="new-password"
        maxLength={25}
        value={values.confirm}
        onChange={(e) => update('confirm', e.target.value)}
        onBlur={() => blur('confirm')}
        error={shouldShow('confirm') ? errors.confirm : undefined}
      />

      <Button type="submit" className="mt-2 h-11 w-full text-sm font-semibold" disabled={pending}>
        {pending ? (
          <>
            <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
            Enviando código…
          </>
        ) : (
          'Crear cuenta'
        )}
      </Button>
    </form>
  )
}

const requirements: { key: keyof ReturnType<typeof checkPassword>; label: string }[] = [
  { key: 'length', label: 'Entre 8 y 25 caracteres' },
  { key: 'uppercase', label: 'Al menos una mayúscula' },
  { key: 'number', label: 'Al menos un número' },
  { key: 'special', label: 'Al menos un carácter especial' },
]

function PasswordChecklist({
  checks,
  active,
}: {
  checks: ReturnType<typeof checkPassword>
  active: boolean
}) {
  return (
    <ul className="grid grid-cols-1 gap-1.5 rounded-lg bg-muted/60 p-3 sm:grid-cols-2" aria-live="polite">
      {requirements.map(({ key, label }) => {
        const ok = checks[key]
        return (
          <li key={key} className="flex items-center gap-2 text-xs">
            <span
              className={cn(
                'flex size-4 shrink-0 items-center justify-center rounded-full',
                ok
                  ? 'bg-primary text-primary-foreground'
                  : active
                    ? 'bg-destructive/15 text-destructive'
                    : 'bg-muted-foreground/20 text-muted-foreground',
              )}
            >
              {ok ? (
                <Check className="size-3" aria-hidden="true" />
              ) : active ? (
                <X className="size-3" aria-hidden="true" />
              ) : null}
            </span>
            <span className={cn(ok ? 'text-foreground' : 'text-muted-foreground')}>{label}</span>
          </li>
        )
      })}
    </ul>
  )
}
