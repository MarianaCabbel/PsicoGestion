'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, LoaderCircle, MailCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const CODE_LENGTH = 6
const RESEND_SECONDS = 30

export function VerifyCodeForm({
  email,
  onVerified,
  onBack,
}: {
  email: string
  onVerified: () => void
  onBack: () => void
}) {
  const [digits, setDigits] = useState<string[]>(Array(CODE_LENGTH).fill(''))
  const [error, setError] = useState<string>('')
  const [pending, setPending] = useState(false)
  const [seconds, setSeconds] = useState(RESEND_SECONDS)
  const inputs = useRef<Array<HTMLInputElement | null>>([])

  useEffect(() => {
    inputs.current[0]?.focus()
  }, [])

  useEffect(() => {
    if (seconds <= 0) return
    const id = setInterval(() => setSeconds((s) => (s > 0 ? s - 1 : 0)), 1000)
    return () => clearInterval(id)
  }, [seconds])

  const code = digits.join('')

  function setDigit(index: number, value: string) {
    setError('')
    setDigits((prev) => {
      const next = [...prev]
      next[index] = value
      return next
    })
  }

  function handleChange(index: number, raw: string) {
    const value = raw.replace(/\D/g, '')
    if (!value) {
      setDigit(index, '')
      return
    }
    // Soporta pegar varios dígitos desde cualquier casilla.
    if (value.length > 1) {
      const chars = value.slice(0, CODE_LENGTH - index).split('')
      setError('')
      setDigits((prev) => {
        const next = [...prev]
        chars.forEach((c, i) => {
          next[index + i] = c
        })
        return next
      })
      const nextFocus = Math.min(index + chars.length, CODE_LENGTH - 1)
      inputs.current[nextFocus]?.focus()
      return
    }
    setDigit(index, value)
    if (index < CODE_LENGTH - 1) inputs.current[index + 1]?.focus()
  }

  function handleKeyDown(index: number, event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key === 'Backspace' && !digits[index] && index > 0) {
      inputs.current[index - 1]?.focus()
    }
    if (event.key === 'ArrowLeft' && index > 0) inputs.current[index - 1]?.focus()
    if (event.key === 'ArrowRight' && index < CODE_LENGTH - 1)
      inputs.current[index + 1]?.focus()
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (code.length < CODE_LENGTH) {
      setError('Ingresa los 6 dígitos del código.')
      return
    }
    setPending(true)
    await new Promise((resolve) => setTimeout(resolve, 700))
    setPending(false)
    onVerified()
  }

  function handleResend() {
    if (seconds > 0) return
    setSeconds(RESEND_SECONDS)
    setDigits(Array(CODE_LENGTH).fill(''))
    setError('')
    inputs.current[0]?.focus()
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col items-center gap-3 text-center">
        <span className="flex size-12 items-center justify-center rounded-full bg-accent text-accent-foreground">
          <MailCheck className="size-6" aria-hidden="true" />
        </span>
        <div>
          <h2 className="text-xl font-semibold text-foreground">Verifica tu correo</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Enviamos un código de 6 dígitos a{' '}
            <span className="font-medium text-foreground">{email}</span>
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <fieldset>
          <legend className="sr-only">Código de verificación de 6 dígitos</legend>
          <div className="flex justify-center gap-2">
            {digits.map((digit, index) => (
              <input
                key={index}
                ref={(el) => {
                  inputs.current[index] = el
                }}
                type="text"
                inputMode="numeric"
                autoComplete={index === 0 ? 'one-time-code' : 'off'}
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onFocus={(e) => e.target.select()}
                aria-label={`Dígito ${index + 1}`}
                aria-invalid={error ? true : undefined}
                className={cn(
                  'size-12 rounded-lg border border-input bg-card text-center text-lg font-semibold text-foreground outline-none transition-colors focus:border-ring focus:ring-2 focus:ring-ring/30 sm:size-14',
                  error && 'border-destructive',
                )}
              />
            ))}
          </div>
          {error ? (
            <p role="alert" className="mt-2 text-center text-xs font-medium text-destructive">
              {error}
            </p>
          ) : null}
        </fieldset>

        <Button type="submit" className="h-11 w-full text-sm font-semibold" disabled={pending}>
          {pending ? (
            <>
              <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
              Verificando…
            </>
          ) : (
            'Verificar código'
          )}
        </Button>
      </form>

      <div className="flex flex-col items-center gap-3 text-sm">
        <p className="text-muted-foreground">
          ¿No recibiste el código?{' '}
          {seconds > 0 ? (
            <span className="text-muted-foreground">
              Reenviar en {seconds}s
            </span>
          ) : (
            <button
              type="button"
              onClick={handleResend}
              className="font-medium text-primary underline-offset-2 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
            >
              Reenviar código
            </button>
          )}
        </p>
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Volver al registro
        </button>
      </div>
    </div>
  )
}
