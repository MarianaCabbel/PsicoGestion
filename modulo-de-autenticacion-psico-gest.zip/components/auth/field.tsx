'use client'

import type { InputHTMLAttributes, ReactNode } from 'react'
import { useId } from 'react'
import { cn } from '@/lib/utils'

type FieldProps = InputHTMLAttributes<HTMLInputElement> & {
  label: string
  icon?: ReactNode
  error?: string
  hint?: string
  /** Extra content rendered inside the field on the right (e.g. show/hide button). */
  trailing?: ReactNode
}

export function Field({
  label,
  icon,
  error,
  hint,
  trailing,
  className,
  id,
  ...props
}: FieldProps) {
  const autoId = useId()
  const inputId = id ?? autoId
  const errorId = `${inputId}-error`
  const hintId = `${inputId}-hint`
  const describedBy = [error ? errorId : null, hint ? hintId : null]
    .filter(Boolean)
    .join(' ')

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={inputId} className="text-sm font-medium text-foreground">
        {label}
      </label>
      <div
        className={cn(
          'flex items-center gap-2 rounded-lg border border-input bg-card px-3 transition-colors focus-within:border-ring focus-within:ring-2 focus-within:ring-ring/30',
          error && 'border-destructive focus-within:border-destructive focus-within:ring-destructive/25',
        )}
      >
        {icon ? <span className="text-muted-foreground">{icon}</span> : null}
        <input
          id={inputId}
          className={cn(
            'h-11 w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/70',
            className,
          )}
          aria-invalid={error ? true : undefined}
          aria-describedby={describedBy || undefined}
          {...props}
        />
        {trailing}
      </div>
      {hint && !error ? (
        <p id={hintId} className="text-xs text-muted-foreground">
          {hint}
        </p>
      ) : null}
      {error ? (
        <p id={errorId} role="alert" className="text-xs font-medium text-destructive">
          {error}
        </p>
      ) : null}
    </div>
  )
}
