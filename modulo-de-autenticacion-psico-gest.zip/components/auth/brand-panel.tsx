import { BrainCircuit, CalendarCheck, ShieldCheck } from 'lucide-react'

const points = [
  {
    icon: CalendarCheck,
    title: 'Agenda centralizada',
    text: 'Administra las citas de la clínica desde un solo lugar.',
  },
  {
    icon: ShieldCheck,
    title: 'Acceso verificado',
    text: 'Cada cuenta administrativa se confirma por correo institucional.',
  },
]

export function BrandPanel() {
  return (
    <aside className="hidden flex-col justify-between bg-primary p-10 text-primary-foreground lg:flex">
      <div className="flex items-center gap-3">
        <span className="flex size-11 items-center justify-center rounded-xl bg-primary-foreground/15">
          <BrainCircuit className="size-6" aria-hidden="true" />
        </span>
        <div>
          <p className="text-lg font-semibold leading-tight">PsicoGestión</p>
          <p className="text-sm text-primary-foreground/70">Clínica Universitaria UADY</p>
        </div>
      </div>

      <div className="max-w-sm">
        <h2 className="text-balance text-2xl font-semibold leading-snug">
          Gestión de citas clínicas para el personal administrativo.
        </h2>
        <ul className="mt-8 flex flex-col gap-6">
          {points.map(({ icon: Icon, title, text }) => (
            <li key={title} className="flex gap-3">
              <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary-foreground/15">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <div>
                <p className="font-medium">{title}</p>
                <p className="text-sm leading-relaxed text-primary-foreground/70">{text}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>

      <p className="text-xs text-primary-foreground/60">
        Uso exclusivo del personal autorizado de la clínica.
      </p>
    </aside>
  )
}
